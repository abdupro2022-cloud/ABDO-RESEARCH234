import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Client-side data layer (IndexedDB) is the source of truth for user content,
// so static export stays fully functional. Server routes power tools + vault.
// Setting ABDO_STATIC=1 produces a static-only build for public demos on hosts
// that don't run a Node server — see CONTRACT.md for the trade-offs.
// Note: Vercel manages the build output; the `output` setting only applies when
// we self-host (or export to a static bundle).
  output: process.env.ABDO_STATIC === "1" ? "export" : undefined,
  images: { unoptimized: process.env.ABDO_STATIC === "1" },
  experimental: {
    optimizePackageImports: ["lucide-react", "motion"],
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
        ],
      },
    ];
  },
};

export default nextConfig;
